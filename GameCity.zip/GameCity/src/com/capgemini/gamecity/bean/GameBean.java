package com.capgemini.gamecity.bean;

public class GameBean {
	
	//Initializing variables
	private String name;
	private int amount;

	//default constructor
	public GameBean() {
		super();
	}
	
	//parameterized constructor
	public GameBean(String name, int amount) {
		super();
		this.name = name;
		this.amount = amount;
	}

	//getters and setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "GameBean [name=" + name + ", amount=" + amount + "]";
	}


}
