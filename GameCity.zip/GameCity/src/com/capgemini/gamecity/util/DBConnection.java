package com.capgemini.gamecity.util;

import java.sql.Connection;
import java.sql.SQLException;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.gamecity.exception.GameCityException;


public class DBConnection 
{
	static Connection connection;

	public static Connection obtainConnection() throws GameCityException {
		try {
			InitialContext context = new InitialContext();
			DataSource source = (DataSource) context
					.lookup("java:/OracleDS");
			connection = source.getConnection();
		} catch (NamingException e) {
			throw new GameCityException("Error while creating datascource::"
					+ e.getMessage());
		} catch (SQLException e) {
			throw new GameCityException("Error while obtaining connection::"
					+ e.getMessage());
		}
		return connection;
	}
}
