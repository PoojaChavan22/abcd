package com.capgemini.gamecity.bean;
public class UserBean {
	
	//Initializing variables
	private int userId;
	private String userName;
	private String address;
	private int cardAmount;
	
	//default constructor
	public UserBean() {
		super();
	}
	
	//parameterized Constructor
	public UserBean(int userId, String userName, String address, int cardAmount) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.address = address;
		this.cardAmount = cardAmount;
	}
	
	//getters and setters
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getCardAmount() {
		return cardAmount;
	}
	public void setCardAmount(int cardAmount) {
		this.cardAmount = cardAmount;
	}

	//toString
	@Override
	public String toString() {
		return "UserBean [userId=" + userId + ", userName=" + userName
				+ ", address=" + address + ", cardAmount=" + cardAmount + "]";
	}



}
