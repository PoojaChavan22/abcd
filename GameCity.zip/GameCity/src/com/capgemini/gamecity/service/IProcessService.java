package com.capgemini.gamecity.service;

import java.util.List;
import com.capgemini.gamecity.bean.GameBean;
import com.capgemini.gamecity.bean.UserBean;
import com.capgemini.gamecity.exception.GameCityException;


public interface IProcessService {
	public void buyGameCard(UserBean userbean)
			throws GameCityException;
	
	public List<GameBean> getGameDetails() throws GameCityException;
}
