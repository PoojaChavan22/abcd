package com.capgemini.gamecity.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.capgemini.gamecity.bean.GameBean;
import com.capgemini.gamecity.bean.UserBean;
import com.capgemini.gamecity.exception.GameCityException;
import com.capgemini.gamecity.util.DBConnection;

public class ProcessDAOImpl implements IProcessDAO {
	Statement statement = null;
	ResultSet rsSet = null;
	PreparedStatement preparedStatement = null;
	
	public int generateUserId() throws GameCityException {
		
		
		int id = 0;
		Connection connection = DBConnection.obtainConnection();

		try {

			Statement stm = connection.createStatement();

			ResultSet res = stm.executeQuery("select seq_users.nextval from dual");

			if (res.next() == false) {
				throw new GameCityException("Failed in generating User Id");
			}

			id = res.getInt(1);

			
			
		} catch (Exception e) {

			throw new GameCityException(e);
		}

		return id;

	}
	
	@Override
	public void buyGameCard(UserBean userbean) throws GameCityException {
		// TODO Auto-generated method stub
		int userId = 0;
		Connection connection = DBConnection.obtainConnection();
		
		String insertSql = "INSERT INTO users VALUES(?,?,?,?)";
		
		try {
			userId = generateUserId();
						System.out.println(userId);
			preparedStatement = connection.prepareStatement(insertSql);
			preparedStatement.setInt(1, userId);
			preparedStatement.setString(2, userbean.getUserName());
			preparedStatement.setString(3, userbean.getAddress());
			preparedStatement.setInt(4, userbean.getCardAmount());

			preparedStatement.executeUpdate();

			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new GameCityException("Error while database interaction:::"
					+ e.getMessage());
		}	
		
	}
	
	@Override
	public List<GameBean> getGameDetails() throws GameCityException 
	{
		List<GameBean> list = new ArrayList<>();
		Connection connection = DBConnection.obtainConnection();
		PreparedStatement preparedStatement = null;

		try {
			preparedStatement = connection
					.prepareStatement("SELECT * FROM ONLINEGAMES");
			 rsSet = preparedStatement.executeQuery();

			int index = 0;
			while (rsSet.next()) {
				list.add(new GameBean(rsSet.getString("name"),rsSet.getInt("amount")));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
		
		
	}
	
}
