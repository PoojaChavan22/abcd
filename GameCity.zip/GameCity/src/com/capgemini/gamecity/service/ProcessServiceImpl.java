package com.capgemini.gamecity.service;

import java.util.List;
import com.capgemini.gamecity.bean.GameBean;
import com.capgemini.gamecity.bean.UserBean;
import com.capgemini.gamecity.dao.ProcessDAOImpl;
import com.capgemini.gamecity.dao.IProcessDAO;
import com.capgemini.gamecity.exception.GameCityException;

public class ProcessServiceImpl implements IProcessService {
	IProcessDAO processDAO;

	public ProcessServiceImpl() {
		processDAO = new ProcessDAOImpl();
	}

	@Override
	public void buyGameCard(UserBean userbean) throws GameCityException {
		processDAO.buyGameCard(userbean);
		
	}

	@Override
	public List<GameBean> getGameDetails() throws GameCityException{
		return processDAO.getGameDetails();
	}
	
	
}
