create table users(user_id number primary key, user_name varchar2(40), address varchar2(80), card_amt number(4));

create table onlinegames(name varchar2(40), amount number(3));

insert into onlinegames values ('Shooting' , 105);
insert into onlinegames values ('Angry Birds' , 95);
insert into onlinegames values ('Temple Run' , 200);
insert into onlinegames values ('Bike Race' , 90);
insert into onlinegames values ('Air Control' , 800);

create sequence seq_users;

drop table users;
drop table onlinegames;
drop sequence seq_users;