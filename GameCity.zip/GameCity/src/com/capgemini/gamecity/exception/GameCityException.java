package com.capgemini.gamecity.exception;

public class GameCityException extends Exception
{
	private static final long serialVersionUID = -5649970975683986932L;

	public GameCityException() {
		super();	
	}

	public GameCityException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public GameCityException(String message, Throwable cause) {
		super(message, cause);
	}

	public GameCityException(String message) {
		super(message);
	}

	public GameCityException(Throwable cause) {
		super(cause);
	}
	
}
