package com.capgemini.gamecity.controller;


import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.capgemini.gamecity.bean.GameBean;
import com.capgemini.gamecity.bean.UserBean;
import com.capgemini.gamecity.exception.GameCityException;
import com.capgemini.gamecity.service.ProcessServiceImpl;
import com.capgemini.gamecity.service.IProcessService;

@WebServlet("/ProcessUser")
public class ProcessUser extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String action = request.getParameter("action");
		RequestDispatcher view = null;
		IProcessService service = new ProcessServiceImpl();
		HttpSession session = request.getSession(false);
		
		if (action != null && action.equalsIgnoreCase("addUser")) {
			try {

				view = getServletContext().getRequestDispatcher("/pages/GameCity.jsp");
				view.forward(request, response);
			} catch (Exception e) {
				request.setAttribute("errMsg", e.getMessage());
				view = getServletContext().getRequestDispatcher("/pages/error.jsp");
				view.forward(request, response);
			}
		}

	
		if (action != null && action.equalsIgnoreCase("Buy Card")) {

			String name = request.getParameter("user_name");
			String address = request.getParameter("address");
			int cardAmt = Integer.parseInt(request.getParameter("card_amt")) - 100;
			UserBean user = new UserBean();

			user.setUserName(name);
			user.setAddress(address);
			user.setCardAmount(cardAmt);

			
			if (session == null) {
				session = request.getSession(true);
			}
			session.setAttribute("UserBean", user);
			session.setAttribute("CardAmount", cardAmt);

			try {
				service.buyGameCard(user);
				List<GameBean> listGame = null;
				listGame = service.getGameDetails();
				session.setAttribute("GameList", listGame);
				view = getServletContext().getRequestDispatcher("/pages/Play.jsp");
				view.forward(request, response);
			} catch (GameCityException e) {
				request.setAttribute("errMsg", e.getMessage());
				view = getServletContext().getRequestDispatcher("/pages/error.jsp");
				view.forward(request, response);
			}
		}

	
		if (action != null && action.equalsIgnoreCase("Play")) {
			if (session != null) {

				int amount = Integer.parseInt(request.getParameter("amount"));

				GameBean gameBean = new GameBean();
				gameBean.setName(request.getParameter("game_name"));
				gameBean.setAmount(Integer.parseInt(request
						.getParameter("game_amount")));

				if (gameBean.getAmount() < amount) {

					session.setAttribute("CardAmount",
							amount - gameBean.getAmount());
					session.setAttribute("GameName", gameBean.getName());

					view = getServletContext().getRequestDispatcher(
							"/pages/success.jsp");
					view.forward(request, response);
				} else {

					session.setAttribute("GameName", gameBean.getName());
					view = getServletContext().getRequestDispatcher("/pages/Topup.jsp");
					view.forward(request, response);
				}

			} else {
				request.setAttribute("errMsg", "Invalid Request");
				view = getServletContext().getRequestDispatcher("/pages/error.jsp");
				view.forward(request, response);
			}
		}

	}

}
